// Original file: null


export interface BoolValue {
  'value'?: (boolean);
}

export interface BoolValue__Output {
  'value': (boolean);
}
