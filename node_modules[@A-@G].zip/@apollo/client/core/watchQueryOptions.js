export {};
//# sourceMappingURL=watchQueryOptions.js.map