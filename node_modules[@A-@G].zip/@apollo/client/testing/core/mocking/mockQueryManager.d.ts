import { QueryManager } from '../../../core/QueryManager';
import { MockedResponse } from './mockLink';
declare const _default: (...mockedResponses: MockedResponse[]) => QueryManager<import("../../../cache").NormalizedCacheObject>;
export default _default;
//# sourceMappingURL=mockQueryManager.d.ts.map