import { MockedResponse } from './mockLink';
import { ObservableQuery } from '../../../core';
declare const _default: (...mockedResponses: MockedResponse[]) => ObservableQuery<any>;
export default _default;
//# sourceMappingURL=mockWatchQuery.d.ts.map