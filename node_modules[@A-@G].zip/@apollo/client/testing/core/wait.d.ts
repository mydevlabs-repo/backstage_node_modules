export declare function wait(ms: number): Promise<void>;
export declare function tick(): Promise<void>;
//# sourceMappingURL=wait.d.ts.map