import gql from 'graphql-tag';
gql.disableFragmentWarnings();
process.on('unhandledRejection', function () { });
//# sourceMappingURL=setup.js.map