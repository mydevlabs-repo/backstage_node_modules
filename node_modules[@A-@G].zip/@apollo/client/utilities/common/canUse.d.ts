export declare const canUseWeakMap: boolean;
export declare const canUseWeakSet: boolean;
export declare const canUseSymbol: boolean;
export declare const canUseAsyncIteratorSymbol: false | typeof Symbol.asyncIterator;
export declare const canUseDOM: boolean;
export declare const canUseLayoutEffect: boolean;
//# sourceMappingURL=canUse.d.ts.map