export * from './batchLink';
//# sourceMappingURL=index.d.ts.map