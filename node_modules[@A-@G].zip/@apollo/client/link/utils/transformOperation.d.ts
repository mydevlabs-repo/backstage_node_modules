import { GraphQLRequest } from '../core';
export declare function transformOperation(operation: GraphQLRequest): GraphQLRequest;
//# sourceMappingURL=transformOperation.d.ts.map