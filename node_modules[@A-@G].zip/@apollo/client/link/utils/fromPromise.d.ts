import { Observable } from '../../utilities';
export declare function fromPromise<T>(promise: Promise<T>): Observable<T>;
//# sourceMappingURL=fromPromise.d.ts.map