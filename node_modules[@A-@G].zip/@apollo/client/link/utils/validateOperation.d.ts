import { GraphQLRequest } from '../core';
export declare function validateOperation(operation: GraphQLRequest): GraphQLRequest;
//# sourceMappingURL=validateOperation.d.ts.map