export * from './batchHttpLink';
//# sourceMappingURL=index.d.ts.map