import { ApolloLink } from './ApolloLink';
export declare const concat: typeof ApolloLink.concat;
//# sourceMappingURL=concat.d.ts.map