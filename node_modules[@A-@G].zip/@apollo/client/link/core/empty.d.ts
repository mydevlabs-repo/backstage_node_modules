import { ApolloLink } from './ApolloLink';
export declare const empty: typeof ApolloLink.empty;
//# sourceMappingURL=empty.d.ts.map