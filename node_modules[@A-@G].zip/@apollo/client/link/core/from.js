import { ApolloLink } from "./ApolloLink.js";
export var from = ApolloLink.from;
//# sourceMappingURL=from.js.map