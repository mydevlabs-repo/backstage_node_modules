import { ApolloLink } from "./ApolloLink.js";
export var concat = ApolloLink.concat;
//# sourceMappingURL=concat.js.map