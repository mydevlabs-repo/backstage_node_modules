import { ApolloLink } from "./ApolloLink.js";
export var execute = ApolloLink.execute;
//# sourceMappingURL=execute.js.map