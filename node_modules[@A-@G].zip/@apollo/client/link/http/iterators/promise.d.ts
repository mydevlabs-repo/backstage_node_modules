export default function promiseIterator<T = ArrayBuffer>(promise: Promise<ArrayBuffer>): AsyncIterableIterator<T>;
//# sourceMappingURL=promise.d.ts.map