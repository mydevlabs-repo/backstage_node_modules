export default function readerIterator<T>(reader: ReadableStreamDefaultReader<T>): AsyncIterableIterator<T>;
//# sourceMappingURL=reader.d.ts.map