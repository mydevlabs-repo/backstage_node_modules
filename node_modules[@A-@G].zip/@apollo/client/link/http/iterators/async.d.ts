export default function asyncIterator<T>(source: AsyncIterableIterator<T>): AsyncIterableIterator<T>;
//# sourceMappingURL=async.d.ts.map