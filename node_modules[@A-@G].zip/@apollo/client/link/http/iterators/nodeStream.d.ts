/// <reference types="node" />
import { Readable as NodeReadableStream } from "stream";
export default function nodeStreamIterator<T>(stream: NodeReadableStream): AsyncIterableIterator<T>;
//# sourceMappingURL=nodeStream.d.ts.map