export declare const createSignalIfSupported: () => {
    controller: boolean;
    signal: boolean;
} | {
    controller: AbortController;
    signal: AbortSignal;
};
//# sourceMappingURL=createSignalIfSupported.d.ts.map