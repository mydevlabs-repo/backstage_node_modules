import '../../utilities/globals';
import { ApolloLink } from '../core';
import { HttpOptions } from './selectHttpOptionsAndBody';
export declare const createHttpLink: (linkOptions?: HttpOptions) => ApolloLink;
//# sourceMappingURL=createHttpLink.d.ts.map