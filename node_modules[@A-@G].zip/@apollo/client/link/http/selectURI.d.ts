import { Operation } from '../core';
export declare const selectURI: (operation: Operation, fallbackURI?: string | ((operation: Operation) => string) | undefined) => any;
//# sourceMappingURL=selectURI.d.ts.map