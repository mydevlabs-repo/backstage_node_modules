import { Response as NodeResponse } from "node-fetch";
export declare function responseIterator<T>(response: Response | NodeResponse): AsyncIterableIterator<T>;
//# sourceMappingURL=responseIterator.d.ts.map