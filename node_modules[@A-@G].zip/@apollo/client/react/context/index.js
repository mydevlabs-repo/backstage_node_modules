import "../../utilities/globals/index.js";
export { ApolloConsumer } from "./ApolloConsumer.js";
export { getApolloContext, getApolloContext as resetApolloContext } from "./ApolloContext.js";
export { ApolloProvider } from "./ApolloProvider.js";
//# sourceMappingURL=index.js.map