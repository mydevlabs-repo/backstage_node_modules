type RealUseSESHookType = typeof import("use-sync-external-store").useSyncExternalStore;
export declare const useSyncExternalStore: RealUseSESHookType;
export {};
//# sourceMappingURL=useSyncExternalStore.d.ts.map