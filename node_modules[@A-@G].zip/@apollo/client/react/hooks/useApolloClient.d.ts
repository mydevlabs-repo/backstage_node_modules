import { ApolloClient } from '../../core';
export declare function useApolloClient(override?: ApolloClient<object>): ApolloClient<object>;
//# sourceMappingURL=useApolloClient.d.ts.map