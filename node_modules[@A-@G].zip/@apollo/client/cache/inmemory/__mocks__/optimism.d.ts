declare const optimism: any;
//# sourceMappingURL=optimism.d.ts.map