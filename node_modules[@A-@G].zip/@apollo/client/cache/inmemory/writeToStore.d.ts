import { SelectionSetNode, FieldNode } from 'graphql';
import { FragmentMap, FragmentMapFunction, StoreObject, Reference } from '../../utilities';
import { NormalizedCache, ReadMergeModifyContext, MergeTree } from './types';
import { StoreReader } from './readFromStore';
import { InMemoryCache } from './inMemoryCache';
import { Cache } from '../../core';
export interface WriteContext extends ReadMergeModifyContext {
    readonly written: {
        [dataId: string]: SelectionSetNode[];
    };
    readonly fragmentMap: FragmentMap;
    lookupFragment: FragmentMapFunction;
    merge<T>(existing: T, incoming: T): T;
    overwrite: boolean;
    incomingById: Map<string, {
        storeObject: StoreObject;
        mergeTree?: MergeTree;
        fieldNodeSet: Set<FieldNode>;
    }>;
    clientOnly: boolean;
    deferred: boolean;
    flavors: Map<string, FlavorableWriteContext>;
}
type FlavorableWriteContext = Pick<WriteContext, "clientOnly" | "deferred" | "flavors">;
export declare class StoreWriter {
    readonly cache: InMemoryCache;
    private reader?;
    private fragments?;
    constructor(cache: InMemoryCache, reader?: StoreReader | undefined, fragments?: import("./fragmentRegistry").FragmentRegistryAPI | undefined);
    writeToStore(store: NormalizedCache, { query, result, dataId, variables, overwrite, }: Cache.WriteOptions): Reference | undefined;
    private processSelectionSet;
    private processFieldValue;
    private flattenFields;
    private applyMerges;
}
export {};
//# sourceMappingURL=writeToStore.d.ts.map