# OpenAPI Specification v2.0 JSON Schema

This is the JSON Schema file for the OpenAPI Specification version 2.0. Download and install it via NPM.

## Install via NPM

```shell
npm install --save swagger-schema-official
```

## License

Apache-2.0
